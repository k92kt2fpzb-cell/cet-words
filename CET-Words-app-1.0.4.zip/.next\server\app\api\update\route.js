var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/update/route.js")
R.c("server/chunks/[root-of-the-server]__1v26-2i._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_update_route_actions_0tvsuhe.js")
R.m(18306)
module.exports=R.m(18306).exports
