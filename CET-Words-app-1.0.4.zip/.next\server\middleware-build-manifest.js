globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/s14Bw2loJ3B5LoEY9foS6/_buildManifest.js",
    "static/s14Bw2loJ3B5LoEY9foS6/_ssgManifest.js",
    "static/s14Bw2loJ3B5LoEY9foS6/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/1rj7ns8rte9vc.js",
    "static/chunks/2z-e6jheq0ftu.js",
    "static/chunks/turbopack-1vijxpa2bdysr.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
