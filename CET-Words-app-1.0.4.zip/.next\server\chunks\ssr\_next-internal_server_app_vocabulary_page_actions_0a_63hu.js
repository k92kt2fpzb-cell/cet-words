module.exports=[26085,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_vocabulary_page_actions_0a_63hu.js.map