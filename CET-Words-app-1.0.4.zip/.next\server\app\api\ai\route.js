var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/route.js")
R.c("server/chunks/[externals]__0bwf06g._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_08r3qxs._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_route_actions_19_py98.js")
R.m(37291)
module.exports=R.m(37291).exports
